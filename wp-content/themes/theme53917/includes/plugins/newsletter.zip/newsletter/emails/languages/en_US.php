<?php

$options = array(
    'theme'=>'default'
);
