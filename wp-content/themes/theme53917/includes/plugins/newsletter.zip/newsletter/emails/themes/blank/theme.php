<p>Blank newsletter!</p>

<p>
    To unsubscribe <a href="{unsubscription_url}">click here</a>, to edit your profile
    <a href="{profile_url}">click here</a>.
</p>
