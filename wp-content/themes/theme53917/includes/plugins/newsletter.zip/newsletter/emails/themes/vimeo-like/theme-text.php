This email requires a modern e-mail reader. You can view the email online here:

{email_url}.

Thank you, <?php echo get_option('blogname'); ?>

To change your subscription follow:
{profile_url}.