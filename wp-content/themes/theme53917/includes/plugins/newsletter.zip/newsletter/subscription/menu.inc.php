<!--<h5>Subscription Module</h5>-->
<div id="newsletter-nav">
    <a class="button" href="<?php echo $module->get_admin_page_url('options'); ?>">Subscription steps</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('profile'); ?>">Form fields and translation</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('forms'); ?>">Alternative forms</a>
</div>