<div class="wrap">

    <?php include NEWSLETTER_DIR . '/header-new.php'; ?>

    <h5>Feed by Mail</h5>

    <h2>Main configuration</h2>

    <?php $controls->show(); ?>

    <div class="updated">
        <p>
            The Feed by Mail demo has been removed to make the plugin faster. You can install the demo separately getting it
            from <a href="http://www.satollo.net/downloads/demos" target="_blank">here</a> or directly the full version from
            <a href="http://www.satollo.net/downloads" target="_blank">here</a>.
        </p>
    </div>

</div>